#topsis
This is for TOPSIS evaluation of a dataset

#Installation
```pip install topsis-aditi-101903527```

#How to use
Open terminal
Then in the command prompt type in the format 
python <program file name(.py file)>  <input data file(.xlsx file)> <string of weight > <string of impacts> <result file name>

